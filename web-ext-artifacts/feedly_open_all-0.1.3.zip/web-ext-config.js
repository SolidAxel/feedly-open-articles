module.exports = {
  ignoreFiles: [
    '.gitignore',
    '*.csproj',
    '*.sln',
    'package-lock.json',
    'node_modules/**',
    'bin',
    'obj',
    '*.iml',
    'README.md',
  ],
};
